/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class LaborDisputes extends javax.swing.JFrame {

    /**
     * Creates new form LaborDisputes
     */
    public LaborDisputes() {
        initComponents();
        
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Undestanding Labor Disputes</h1>"
        + "<p>Labor disputes arise when employees and employers face disagreements related to wages, working conditions, benefits, terminations, or other employment rights. Employees involved in such disputes should understand their rights, consequences, and obligations to resolve issues effectively while maintaining their legal and professional standing.</p>"
        + "<h2>Common Labor Disputes from the Employee’s Perspective</h2>"
        + "<ul>"
        + "<li><b>Unfair Dismissal or Termination</b><br>Claims of termination without just or authorized cause or without due process.</li>"
        + "<li><b>Non-Payment of Wages or Benefits</b><br>Employers failing to pay wages, overtime pay, 13th-month pay, or other statutory benefits.</li>"
        + "<li><b>Harassment or Discrimination</b><br>Complaints of workplace harassment or discrimination based on race, gender, religion, or other factors.</li>"
        + "<li><b>Unsafe Working Conditions</b><br>Employees raising issues about unsafe or hazardous working conditions.</li>"
        + "<li><b>Contractualization and Labor-Only Contracting</b><br>Complaints about being hired under unfair labor-only contracting schemes or 'endo' (end of contract practices).</li>"
        + "<li><b>Union-Related Disputes</b><br>Issues concerning the right to unionize or participate in collective bargaining activities.</li>"
        + "</ul>"
        + "<h2>Consequences of Labor Disputes</h2>"
        + "<h3>1. On Employees</h3>"
        + "<ul>"
        + "<li>Job Loss: Employees may face retaliation or termination (legal or illegal) during or after raising disputes.</li>"
        + "<li>Legal Costs: Pursuing cases before labor tribunals may involve legal fees and other costs.</li>"
        + "<li>Emotional and Professional Strain: Stress and potential damage to reputation within the industry.</li>"
        + "</ul>"
        + "<h3>2. On Employers</h3>"
        + "<ul>"
        + "<li>Financial Penalties: Non-compliance with labor laws can lead to fines, back pay, or damages.</li>"
        + "<li>Operational Disruptions: Labor strikes or disputes can interrupt business operations.</li>"
        + "<li>Reputational Damage: Negative publicity from disputes may harm the company’s image.</li>"
        + "</ul>"
        + "<h2>Obligations for Employees During Labor Disputes</h2>"
        + "<ul>"
        + "<li><b>Document Evidence</b><br>Keep a record of relevant documents, such as employment contracts, payslips, correspondence, and witness accounts, to support claims.</li>"
        + "<li><b>Follow Legal Channels</b><br>File a complaint with the Department of Labor and Employment (DOLE) or proceed to the National Labor Relations Commission (NLRC) for arbitration.</li>"
        + "<li><b>Participate in Mediation</b><br>Employees must actively participate in mediation and conciliation proceedings facilitated by DOLE or other authorized bodies before escalating the case.</li>"
        + "<li><b>Adhere to Contract Terms</b><br>While disputing issues, employees must honor valid contract provisions unless directed otherwise by legal authorities.</li>"
        + "<li><b>Avoid Retaliatory Actions</b><br>Refrain from engaging in illegal strikes, boycotts, or sabotage, which could lead to termination or criminal charges.</li>"
        + "</ul>"
        + "<h2>Mechanisms for Resolving Labor Disputes</h2>"
        + "<h3>1. Mediation and Conciliation (DOLE)</h3>"
        + "<p>When a group of employees reports unsafe working conditions and unpaid overtime, DOLE steps in to mediate. Through facilitated discussions, the employer agrees to improve safety measures and pay overdue overtime. Both parties reach an amicable settlement without escalating the issue further.</p>"
        + "<h3>2. Arbitration (NLRC)</h3>"
        + "<p>In cases where mediation fails, such as when an employee claims wrongful termination, the dispute is brought to the NLRC. After reviewing evidence, the NLRC rules in favor of the employee, determining the termination was unjust. The employer is ordered to reinstate the employee and pay back wages, with the decision being legally binding.</p>"
        + "<h3>3. Labor Arbitration Awards</h3>"
        + "<p>If a company refuses to pay severance benefits after downsizing, employees can file a case with the NLRC. The arbitrators decide in favor of the employees, awarding them severance pay, damages for the delay, and emotional compensation. The company must comply within a set timeframe.</p>"
        + "<h3>4. Voluntary Arbitration</h3>"
        + "<p>A disagreement over the interpretation of a collective bargaining agreement (CBA), such as vacation leave entitlements, can be resolved through voluntary arbitration. Both the employer and union select a neutral arbitrator, who rules in favor of the employees, clarifying that the disputed leave is indeed part of the agreement. Both parties accept and implement the decision.</p>"
        + "<h3>5. Strikes and Lockouts</h3>"
        + "<p><b>Strike Scenario:</b> Workers demand higher wages but fail to negotiate successfully with the employer. They organize a legal strike, halting operations. After two weeks, the employer agrees to negotiate, resulting in a partial wage increase and improved benefits.</p>"
        + "<p><b>Lockout Scenario:</b> A retail company faces repeated employee protests over a new policy on flexible working hours. The employer declares a temporary lockout and files a notice with DOLE. During negotiations, the policy is revised to balance flexibility for employees with operational requirements, leading to an agreement.</p>"
        + "<p>Labor disputes can be challenging for both employees and employers. Employees must assert their rights through legal channels while maintaining professionalism, and employers must ensure compliance with labor laws to avoid disputes. By fostering open communication and adhering to fair practices, many labor issues can be resolved or prevented entirely.</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Labor Disputes");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(362, 362, 362)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(379, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LaborDisputes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LaborDisputes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LaborDisputes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LaborDisputes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LaborDisputes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
