/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class SavingTips extends javax.swing.JFrame {

    /**
     * Creates new form SavingTips
     */
    public SavingTips() {
        initComponents();
        
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
         
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Tax-Saving Tips</h1>"
        + "<p>Tax-saving tips are strategies that individuals and businesses can employ to minimize their tax liability and maximize their financial well-being. These tips often involve understanding and leveraging various tax deductions, credits, and other provisions within the tax code. Here's a comprehensive exploration of the tax-saving tips you provided, along with additional insights:</p>"
        + "<h2>Maximizing Deductions</h2>"
        + "<h3>Importance of Record Keeping:</h3>"
        + "<ul>"
        + "<li><b>Documentation is Key:</b> Keeping all receipts and invoices for deductible expenses is crucial. This documentation serves as proof of your expenses and helps you substantiate your claims during a tax audit.</li>"
        + "<li><b>Organized System:</b> Create a system for storing receipts, such as a dedicated folder or digital filing system. This will make it easier to locate the necessary documentation when preparing your tax return.</li>"
        + "<li><b>Digital Backup:</b> Consider scanning receipts and invoices to create digital copies. This provides an extra layer of protection in case the physical receipts are lost or damaged.</li>"
        + "</ul>"
        + "<h3>Common Deductible Expenses:</h3>"
        + "<ul>"
        + "<li><b>Home Ownership:</b> Mortgage interest payments, property taxes, and insurance premiums are often deductible for homeowners.</li>"
        + "<li><b>Business Expenses:</b> Self-employed individuals and business owners can deduct expenses related to their trade or business, such as rent, utilities, supplies, and travel.</li>"
        + "<li><b>Medical Expenses:</b> Deductible medical expenses include doctor's fees, prescription drugs, and insurance premiums.</li>"
        + "<li><b>Charitable Contributions:</b> Donations to qualified charitable organizations are deductible, and you can deduct the fair market value of donated goods.</li>"
        + "</ul>"
        + "<h2>Utilizing Tax Credits</h2>"
        + "<h3>Tax Credits vs. Deductions:</h3>"
        + "<ul>"
        + "<li><b>Direct Reduction:</b> Tax credits directly reduce your tax liability, dollar for dollar. This means they are more valuable than deductions, which only reduce your taxable income.</li>"
        + "<li><b>Creditable Withholding Tax Certificates (BIR Form No. 2307):</b> These certificates provide proof of taxes withheld from your income. This can be helpful in claiming tax credits, such as the creditable withholding tax credit.</li>"
        + "</ul>"
        + "<h3>Common Tax Credits:</h3>"
        + "<ul>"
        + "<li><b>Earned Income Tax Credit (EITC):</b> A refundable tax credit for low- to moderate-income working individuals and families.</li>"
        + "<li><b>Child Tax Credit:</b> A tax credit for each qualifying child under the age of 17.</li>"
        + "<li><b>American Opportunity Tax Credit:</b> A tax credit for qualified education expenses.</li>"
        + "</ul>"
        + "<h2>Charitable Contributions</h2>"
        + "<h3>Accredited Institutions:</h3>"
        + "<ul>"
        + "<li><b>BIR Form 2322:</b> This form serves as a Certificate of Donation, which is required to claim a deduction for charitable contributions. You should obtain this form from the accredited institution you donate to.</li>"
        + "<li><b>Qualified Organizations:</b> Ensure that the organization you donate to is a qualified charitable organization recognized by the Bureau of Internal Revenue (BIR).</li>"
        + "</ul>"
        + "<h3>Maximizing Your Deduction:</h3>"
        + "<ul>"
        + "<li><b>Non-Cash Donations:</b> You can deduct the fair market value of donated goods, such as clothing, furniture, or vehicles.</li>"
        + "<li><b>Timing of Donations:</b> Consider donating to charity in a year when you expect to be in a higher tax bracket, as your deduction will be more valuable.</li>"
        + "</ul>"
        + "<h2>Optional Standard Deduction (OSD)</h2>"
        + "<ul>"
        + "<li><b>Standard Deduction:</b> This is a fixed amount that you can choose to deduct from your taxable income instead of itemizing your deductions.</li>"
        + "<li><b>Itemized Deductions:</b> These are specific expenses that you can deduct, such as medical expenses, mortgage interest, and charitable contributions.</li>"
        + "<li><b>Choose the Best Option:</b> Compare the amount of the standard deduction to the total amount of your itemized deductions. Choose the option that results in the lower taxable income and, therefore, the lower tax liability.</li>"
        + "</ul>"
        + "<h2>Income Splitting</h2>"
        + "<ul>"
        + "<li><b>Family Members:</b> Income splitting involves distributing income among family members, such as spouses or children, to take advantage of different tax brackets. This can be particularly beneficial if one family member has a higher income and is in a higher tax bracket.</li>"
        + "<li><b>Tax Planning:</b> Income splitting should be carefully planned and executed to ensure compliance with tax laws. It's advisable to consult with a tax professional to determine the best approach for your specific circumstances.</li>"
        + "</ul>"
        + "<h2>Timing of Income and Expenses</h2>"
        + "<ul>"
        + "<li><b>Income Timing:</b> Try to defer income into a later tax year if you expect to be in a lower tax bracket in the future. This can help you pay less tax overall.</li>"
        + "<li><b>Expense Timing:</b> Consider accelerating deductible expenses into the current tax year if you expect to be in a higher tax bracket in the future. This can help you reduce your tax liability for the current year.</li>"
        + "<li><b>Tax Planning:</b> Careful planning and timing of income and expenses can significantly impact your tax bill. It's essential to consult with a tax professional to develop a tax plan that aligns with your financial goals.</li>"
        + "</ul>"
        + "<h2>Additional Tax-Saving Tips</h2>"
        + "<ul>"
        + "<li><b>Retirement Savings:</b> Contribute to a 401(k) or IRA to reduce your taxable income and save for retirement.</li>"
        + "<li><b>Health Savings Accounts (HSAs):</b> If you have a high-deductible health plan, consider contributing to an HSA. Contributions are tax-deductible, and withdrawals are tax-free when used for qualified medical expenses.</li>"
        + "<li><b>Flexible Spending Accounts (FSAs):</b> These accounts allow you to pay for certain expenses, such as medical or dependent care, with pre-tax dollars, reducing your taxable income.</li>"
        + "<li><b>Tax-Loss Harvesting:</b> Selling losing investments to offset capital gains and reduce your tax liability.</li>"
        + "</ul>"
        + "<p>Tax-saving tips can be a valuable tool for individuals and businesses looking to minimize their tax liability. By understanding and leveraging the various provisions within the tax code, you can potentially save money and maximize your financial resources. However, it's crucial to consult with a tax professional to ensure that you are using these tips correctly and in compliance with all applicable tax laws. Remember, accurate record keeping, careful planning, and expert advice are essential for successful tax savings.</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content


    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel2.setForeground(new java.awt.Color(0, 102, 102));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Tax-Saving Tips");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(368, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(351, 351, 351))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 110));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 1030, 680));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 799, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 807));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SavingTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SavingTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SavingTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SavingTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SavingTips().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
