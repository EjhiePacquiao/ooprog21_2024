/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class EmployBene extends javax.swing.JFrame {

    /**
     * Creates new form EmployBene
     */
    public EmployBene() {
        initComponents();
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Employee Benefits</h1>"
        + "<h2>1. Statutory Benefits (Applicable to both Public and Private Sectors)</h2>"
        + "<ol>"
        + "<li><b>Minimum Wage:</b><br>"
        + "All employees, whether in the private or public sector, are entitled to receive at least the minimum wage set by regional wage boards, which vary depending on the region and industry.</li>"
        + "<li><b>13th Month Pay:</b><br>"
        + "Every employee is entitled to a 13th month pay, which is equivalent to one-twelfth (1/12) of the employee’s total basic salary earned within the calendar year.</li>"
        + "<li><b>Social Security System (SSS):</b><br>"
        + "Employees are entitled to SSS benefits, including those for retirement, sickness, disability, maternity, and death. Employers are required to contribute to the SSS on behalf of their employees.</li>"
        + "<li><b>PhilHealth (Health Insurance):</b><br>"
        + "Employees are entitled to health insurance coverage under PhilHealth, which provides medical benefits for hospitalization and outpatient care. Employers must contribute a portion of the employee's PhilHealth premiums.</li>"
        + "<li><b>Pag-IBIG Fund (Housing and Financial Benefits):</b><br>"
        + "Employees are entitled to contributions to the Pag-IBIG Fund, which provides benefits such as housing loans, savings programs, and financial assistance. Employers are required to contribute a portion of the employee’s Pag-IBIG premium.</li>"
        + "<li><b>Service Incentive Leave (SIL):</b><br>"
        + "Employees are entitled to five (5) days of paid service incentive leave after completing one year of service. Unused SIL can be converted to cash at the end of the year.</li>"
        + "<li><b>Sick Leave:</b><br>"
        + "Employees in the private sector are typically entitled to sick leave benefits. The number of days varies depending on company policy, although sick leave is not mandated by law, unlike other benefits.</li>"
        + "<li><b>Vacation Leave:</b><br>"
        + "Vacation leave is generally offered by private companies. Although it is not required by law, many companies provide paid vacation leave to employees.</li>"
        + "<li><b>Maternity Leave:</b><br>"
        + "Female employees are entitled to 105 days of paid maternity leave, regardless of the method of delivery (normal or cesarean). An additional 15 days of paid leave is available for solo parents. Employees can extend this period with an additional 30 days of leave without pay.</li>"
        + "<li><b>Paternity Leave:</b><br>"
        + "Male employees are entitled to 7 days of paid paternity leave upon the birth of their child.</li>"
        + "<li><b>Parental Leave for Single Parents:</b><br>"
        + "Single parents are entitled to 7 days of paid leave per year under the Single Parent Act.</li>"
        + "<li><b>Bereavement Leave:</b><br>"
        + "Employees are entitled to 10 days of paid leave following the death of an immediate family member (such as spouse, parent, child, sibling).</li>"
        + "<li><b>Christmas Bonus:</b><br>"
        + "<ul><li><b>Private Sector:</b><br></li>"
        + "The Christmas Bonus is not mandatory by law. Companies are required to pay the 13th Month Pay, which is often considered a form of Christmas Bonus. The 13th Month Pay must be paid to all employees, but other holiday bonuses (e.g., performance bonuses) are not required by law and depend on company policy.<br>"
        + "<li><b>Public Sector:</b><br></li></u>"
        + "The Christmas Bonus is typically granted as part of the government’s benefits package. It is often provided as a Performance-Based Bonus (PBB), based on the employee's performance evaluation for the year. While not specifically mandated by law, the Christmas Bonus in the public sector is a common and widely expected benefit.</li>"
        + "</ol>"
        + "<h2>2. Additional Benefits in the Public Sector</h2>"
        + "<ol>"
        + "<li><b>Additional Leave Benefits:</b><br>"
        + "Public sector employees are entitled to additional types of leave benefits, including:<br>"
        + "<ul>"
        + "<li>Vacation Leave: Generally, public employees are entitled to 15 days of paid vacation leave annually.</li>"
        + "<li>Sick Leave: Public employees are granted 15 days of paid sick leave annually.</li>"
        + "<li>Special Leave Privileges: For employees in hazardous jobs or positions with special working conditions.</li>"
        + "</ul></li>"
        + "<li><b>Government Service Insurance System (GSIS):</b><br>"
        + "Public employees are entitled to benefits under the GSIS, which covers social security and retirement benefits, including pensions, loans, insurance, and other welfare programs.</li>"
        + "<li><b>Additional Maternity Benefits:</b><br>"
        + "Some public employees are entitled to additional maternity benefits or child care leave, exceeding the standard private sector maternity leave period.</li>"
        + "<li><b>Longevity Pay:</b><br>"
        + "Some public sector employees may receive longevity pay as a reward for long years of service. This is typically given after a certain number of years of service (e.g., after 10, 20, or more years).</li>"
        + "<li><b>Year-End Bonus:</b><br>"
        + "Public sector employees are often entitled to a Year-End Bonus, which is separate from the Christmas Bonus. This is typically equivalent to one month’s salary and is provided in December.</li>"
        + "<li><b>Hazard Pay:</b><br>"
        + "Employees working in dangerous or hazardous conditions (such as healthcare workers, security personnel, etc.) may be entitled to hazard pay as part of their benefits.</li>"
        + "</ol>"
        + "<h2>3. Freelancers and Self-Employed Employees</h2>"
        + "<ol>"
        + "<li><b>SSS Membership:</b><br>"
        + "Freelancers are required to register with the SSS and pay contributions. They can avail of retirement, disability, sickness, and maternity benefits if they meet the requirements.</li>"
        + "<li><b>PhilHealth and Pag-IBIG Contributions:</b><br>"
        + "Freelancers are also eligible for PhilHealth and Pag-IBIG coverage by voluntarily contributing to both institutions, ensuring health insurance coverage and access to housing programs.</li>"
        + "<li><b>Tax Incentives:</b><br>"
        + "Freelancers may be entitled to tax deductions, such as deductions for business-related expenses (e.g., office supplies, internet, business-related travel). The Tax Reform for Acceleration and Inclusion (TRAIN) law allows simplified tax filing for freelancers earning below a certain income threshold.</li>"
        + "<li><b>Workers' Compensation for Freelancers:</b><br>"
        + "Freelancers, in certain cases, may apply for workers' compensation if they become ill or injured while performing their duties. Freelancers should enroll in the appropriate insurance programs to ensure coverage.</li>"
        + "</ol>"
        + "<p>Employee benefits in the Philippines, whether in the public or private sector, are designed to ensure the welfare, safety, and well-being of workers. These benefits include mandatory entitlements such as minimum wage, social security, and health insurance, along with other leave benefits like maternity, paternity, and sick leave. Freelancers and self-employed individuals also have access to some benefits like social security contributions, health insurance, and tax incentives. Understanding these benefits is crucial for both employees and employers to ensure compliance with Philippine labor laws.</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Employee Benefits");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(350, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(331, 331, 331))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 670));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployBene.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployBene.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployBene.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployBene.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployBene().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
