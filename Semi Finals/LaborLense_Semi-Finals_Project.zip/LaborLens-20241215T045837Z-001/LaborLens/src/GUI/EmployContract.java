/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class EmployContract extends javax.swing.JFrame {

    /**
     * Creates new form EmployContract
     */
    public EmployContract() {
        initComponents();
        
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "table { width: 100%; border-collapse: collapse; margin-top: 10px; }"
        + "th, td { border: 1px solid black; padding: 8px; text-align: left; }"
        + "th { background-color: #f2f2f2; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Employment Contracts in the Philippines</h1>"
        + "<p>Employment contracts outline the terms and conditions of an employee's relationship with their employer. These contracts are regulated by the Labor Code of the Philippines to ensure fairness and transparency.</p>"
        + "<h2>Types of Employment Contracts</h2>"
        + "<ul>"
        + "<li><b>Regular (Permanent) Employment:</b> For employees who have passed the probationary period. Includes job security and benefits such as leave entitlements and tenure-related rights.</li>"
        + "<li><b>Probationary Employment:</b> Typically lasts up to six months, allowing the employer to evaluate the employee's suitability for the job. Must include clear criteria for regularization; failure to provide this may result in automatic regularization.</li>"
        + "<li><b>Project-Based Employment:</b> Employment is tied to the completion of a specific project. Ends upon project completion unless renewed or transitioned to regular employment.</li>"
        + "<li><b>Seasonal Employment:</b> Applicable to industries with cyclical demand (e.g., agriculture, tourism). Employees are hired for specific seasons and may be rehired for subsequent cycles.</li>"
        + "<li><b>Fixed-Term (Contractual) Employment:</b> Employment for a specific period or until a task is completed. Cannot be used to circumvent regularization laws.</li>"
        + "<li><b>Casual Employment:</b> For jobs incidental to the employer's usual business. Employment does not exceed one year and is not regularized unless the nature of work becomes essential.</li>"
        + "<li><b>Freelance/Consultancy Contracts:</b> Independent contractors are hired for specific tasks. These workers are not considered employees and are not entitled to standard employee benefits under labor laws.</li>"
        + "</ul>"
        + "<h2>Key Clauses to Look For in Employment Contracts</h2>"
        + "<ul>"
        + "<li><b>Job Description:</b> Clearly defines the employee's role, duties, and responsibilities.</li>"
        + "<li><b>Compensation and Benefits:</b> Specifies salary, allowances, bonuses, and non-wage benefits such as health insurance and leave entitlements.</li>"
        + "<li><b>Working Hours and Overtime:</b> Details the standard working hours, rest days, and overtime policies.</li>"
        + "<li><b>Probationary Period:</b> Includes duration, evaluation criteria, and conditions for regularization.</li>"
        + "<li><b>Termination Conditions:</b> Explains valid reasons for termination and required notice periods, following the Labor Code.</li>"
        + "<li><b>Confidentiality and Non-Disclosure:</b> Protects sensitive company information from being disclosed or misused.</li>"
        + "<li><b>Non-Compete and Non-Solicitation Clauses:</b> Restricts employees from working with competitors or poaching clients/staff for a defined period after leaving the company.</li>"
        + "<li><b>Dispute Resolution:</b> Outlines procedures for resolving conflicts, such as mediation or arbitration.</li>"
        + "<li><b>Employment Duration:</b> Specifies whether the contract is permanent, fixed-term, or project-based.</li>"
        + "</ul>"
        + "<h2>Probationary vs. Permanent Employment</h2>"
        + "<table>"
        + "<tr><th>Aspect</th><th>Probationary Employment</th><th>Permanent Employment</th></tr>"
        + "<tr><td>Duration</td><td>Up to six months</td><td>No set end date</td></tr>"
        + "<tr><td>Job Security</td><td>Conditional on meeting criteria</td><td>High, termination requires just cause</td></tr>"
        + "<tr><td>Benefits</td><td>Limited benefits</td><td>Full benefits under labor laws</td></tr>"
        + "<tr><td>Termination</td><td>Easier, if performance criteria not met</td><td>Requires just or authorized cause</td></tr>"
        + "</table>"
        + "<h2>Other Employment Considerations</h2>"
        + "<ul>"
        + "<li><b>Project-Based and Seasonal Employees:</b> They have specific rights, such as pro-rata benefits, depending on the nature of their work.</li>"
        + "<li><b>Contractual Employees:</b> Must not be abused to avoid granting employees their regular status and benefits.</li>"
        + "<li><b>Freelancers and Consultants:</b> Governed by Civil Code provisions, not the Labor Code. Should negotiate terms on payment, deliverables, and intellectual property.</li>"
        + "</ul>"
        + "<h2>Best Practices for Employees</h2>"
        + "<ul>"
        + "<li><b>Read the Contract Thoroughly:</b> Ensure you understand the terms before signing.</li>"
        + "<li><b>Clarify Ambiguities:</b> Ask questions if any clauses are unclear or seem unfair.</li>"
        + "<li><b>Retain a Copy:</b> Keep a signed copy of the contract for reference.</li>"
        + "<li><b>Seek Legal Advice:</b> For disputes or concerns, consult the DOLE or a labor lawyer.</li>"
        + "</ul>"
        + "<p>By understanding employment contracts, employees can protect their rights and foster a clear, professional relationship with their employer.</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Employment Contracts");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(340, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 432, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(258, 258, 258))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 650));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployContract.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployContract.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployContract.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployContract.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployContract().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
