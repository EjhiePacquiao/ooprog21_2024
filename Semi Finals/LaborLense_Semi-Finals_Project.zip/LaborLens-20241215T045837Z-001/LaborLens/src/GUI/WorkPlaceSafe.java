/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class WorkPlaceSafe extends javax.swing.JFrame {

    /**
     * Creates new form WorkPlaceSafe
     */
    public WorkPlaceSafe() {
        initComponents();
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Workplace Safety & Health in the Philippines: Employee Rights and Reporting Unsafe Conditions</h1>"
        + "<p>The Philippines has a robust legal framework that protects employees' rights to a safe and healthy working environment. This framework is built upon the Labor Code of the Philippines, the Occupational Safety and Health Standards (OSHS), and other relevant regulations. Here's a breakdown of employee rights and the process for reporting unsafe conditions:</p>"
        + "<h2>Employee Rights Regarding Safe and Healthy Working Conditions</h2>"
        + "<ul>"
        + "<li><b>Right to a Safe Workplace:</b> Employers are obligated to provide a workplace free from recognized hazards that could cause death or serious harm. This includes ensuring safe work areas, equipment, processes, proper handling of hazardous substances, and adequate sanitation and facilities.</li>"
        + "<li><b>Right to Information:</b> Employees have the right to be informed about potential hazards, safety rules, and appropriate protective measures. They should be provided with training on chemical safety, electrical safety, mechanical safety, ergonomics, and other hazards and risks.</li>"
        + "<li><b>Right to Refuse Unsafe Work:</b> If an employee reasonably believes that a clear and imminent danger to life or health exists, they have the right to refuse to perform the work without fear of reprisal from the employer.</li>"
        + "<li><b>Right to Personal Protective Equipment (PPE):</b> Employers must provide employees with appropriate PPE free of charge, tailored to the specific risks associated with their industry. This includes items like helmets, gloves, safety glasses, and protective clothing.</li>"
        + "<li><b>Right to Participate in Safety Programs:</b> Employees have the right to participate in the OSH program, including through the safety and health committee, and to provide feedback on safety procedures.</li>"
        + "<li><b>Right to Compensation for Work-Related Injuries:</b> Employees are entitled to compensation for work-related injuries, including access to medical benefits and support in case of accidents.</li>"
        + "</ul>"
        + "<h2>Reporting Unsafe Workplace Conditions to DOLE</h2>"
        + "<p>Employees have the right to report accidents, dangerous occurrences, and hazards to their employer, the DOLE, and other concerned government agencies. Here's how to report unsafe conditions:</p>"
        + "<ul>"
        + "<li><b>Report to Employer:</b> The first step is to report the unsafe condition to your employer, ideally in writing. Document the specific hazard, its location, and any potential risks.</li>"
        + "<li><b>Contact DOLE:</b> If the employer fails to address the issue, or if you feel unsafe reporting it directly, you can contact the DOLE. You can reach them through:"
        + "<ul>"
        + "<li>DOLE Hotline: 1349</li>"
        + "<li>DOLE Regional/Field Offices: Find the nearest office on the DOLE website.</li>"
        + "<li>DOLE Call Center: 527-8000</li>"
        + "</ul></li>"
        + "<li><b>Provide Detailed Information:</b> When reporting to the DOLE, provide as much detail as possible, including:"
        + "<ul>"
        + "<li>Your name and contact information</li>"
        + "<li>The name and address of the company</li>"
        + "<li>The specific hazard you are reporting</li>"
        + "<li>The location of the hazard</li>"
        + "<li>Any potential risks associated with the hazard</li>"
        + "<li>Any attempts you have made to report the hazard to your employer</li>"
        + "</ul></li>"
        + "<li><b>Documentation:</b> If possible, gather supporting documentation like photos, videos, or witness statements to strengthen your report.</li>"
        + "<li><b>Anonymity:</b> You can choose to remain anonymous when reporting, but providing your identity can help the DOLE investigate the situation more effectively.</li>"
        + "</ul>"
        + "<h2>Consequences for Non-Compliance</h2>"
        + "<ul>"
        + "<li><b>Fines and Penalties:</b> Employers who fail to comply with safety standards may be fined up to ₱100,000 per day of non-compliance.</li>"
        + "<li><b>Work Stoppage Orders:</b> DOLE can issue a work stoppage order (WSO) if the workplace is deemed hazardous.</li>"
        + "</ul>"
        + "<h2>DOLE's Role in Enforcing Workplace Safety</h2>"
        + "<p>The DOLE is responsible for enforcing OSH laws and regulations. They conduct inspections, issue compliance orders, and impose penalties on employers who fail to provide a safe working environment. The DOLE can also issue work stoppage orders if a workplace is deemed unsafe.</p>"
        + "<p>Employee rights to a safe and healthy workplace are fundamental in the Philippines. Employees have the right to be informed about hazards, refuse unsafe work, and report unsafe conditions to the DOLE. By understanding these rights and the reporting process, employees can help ensure a safer and more productive work environment for themselves and their colleagues.</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Workplace Safety & Health");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(281, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(260, 260, 260))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 120));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 930, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 670));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 794, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 802));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WorkPlaceSafe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WorkPlaceSafe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WorkPlaceSafe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WorkPlaceSafe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WorkPlaceSafe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
