/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class DiscipActions extends javax.swing.JFrame {

    /**
     * Creates new form DiscipActions
     */
    public DiscipActions() {
        initComponents();
        
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Disciplinary Actions in the Workplace</h1>"
        + "<p>In the Philippines, disciplinary actions are governed by the Labor Code to ensure fairness and due process. Employers are responsible for maintaining order and discipline while respecting employees' rights. Below are the key aspects of disciplinary actions.</p>"
        + "<h2>Grounds for Disciplinary Action</h2>"
        + "<ul>"
        + "<li><b>Serious Misconduct:</b> Examples: Physical assault, theft, fraud, harassment, or gross insubordination.</li>"
        + "<li><b>Negligence or Inefficiency:</b> Examples: Repeated failure to meet performance standards or disregarding workplace safety protocols.</li>"
        + "<li><b>Violation of Company Policies:</b> Examples: Unauthorized absences, tardiness, or breaching confidentiality agreements.</li>"
        + "<li><b>Dishonesty or Fraudulent Acts:</b> Examples: Falsifying documents or misuse of company funds.</li>"
        + "<li><b>Gross and Habitual Neglect of Duties:</b> Example: Chronic absenteeism without valid reasons.</li>"
        + "<li><b>Commission of a Crime:</b> If the act is related to the employee’s work or affects workplace harmony.</li>"
        + "<li><b>Conflict of Interest:</b> Examples: Engaging in business activities that directly compete with the employer.</li>"
        + "</ul>"
        + "<h2>Due Process in Disciplinary Proceedings</h2>"
        + "<ul>"
        + "<li><b>Substantive Due Process:</b> There must be a valid and just cause for disciplinary action.</li>"
        + "<li><b>Procedural Due Process:</b> <ul>"
        + "<li><b>Notice to Explain (NTE):</b> A written notice must inform the employee of the alleged misconduct and allow them to respond within a reasonable period.</li>"
        + "<li><b>Hearing or Conference:</b> Employers must provide the employee with an opportunity to defend themselves in a formal setting.</li>"
        + "<li><b>Decision Notice:</b> A written decision explaining the findings and the disciplinary action, if any, must be given to the employee.</li>"
        + "</ul></li>"
        + "</ul>"
        + "<h2>Grievance Procedures</h2>"
        + "<ul>"
        + "<li><b>Internal Grievance Process:</b> Companies often have procedures outlined in their policies. Employees may raise concerns with a supervisor, HR, or a grievance committee.</li>"
        + "<li><b>Department of Labor and Employment (DOLE):</b> If internal grievance mechanisms fail, employees can file a complaint with DOLE.</li>"
        + "<li><b>National Labor Relations Commission (NLRC):</b> For cases involving illegal dismissal or violations of labor standards.</li>"
        + "</ul>"
        + "<h2>Penalties for Misconduct</h2>"
        + "<ul>"
        + "<li><b>Verbal or Written Warning:</b> For minor infractions like tardiness or dress code violations.</li>"
        + "<li><b>Suspension Without Pay:</b> For more serious violations. This must not exceed 30 days.</li>"
        + "<li><b>Demotion:</b> As an alternative to dismissal, employers may reduce an employee's rank or responsibilities.</li>"
        + "<li><b>Dismissal or Termination:</b> Reserved for grave offenses with just or authorized causes.</li>"
        + "</ul>"
        + "<h2>Prohibited Disciplinary Actions</h2>"
        + "<p>Employers must not impose penalties that:</p>"
        + "<ul>"
        + "<li>Violate an employee’s dignity or rights (e.g., public shaming).</li>"
        + "<li>Contradict the company’s code of conduct or existing laws.</li>"
        + "<li>Discriminate based on race, gender, religion, or similar factors.</li>"
        + "</ul>"
        + "<h2>Best Practices for Employers</h2>"
        + "<ul>"
        + "<li><b>Develop Clear Policies:</b> Ensure that company rules, offenses, and corresponding penalties are clearly stated in an employee handbook.</li>"
        + "<li><b>Communicate Expectations:</b> Educate employees about company rules and disciplinary procedures during onboarding or regular training sessions.</li>"
        + "<li><b>Apply Discipline Fairly:</b> Avoid favoritism or bias in disciplinary actions.</li>"
        + "<li><b>Document Everything:</b> Keep detailed records of offenses, investigations, and disciplinary proceedings for transparency and legal compliance.</li>"
        + "</ul>"
        + "<h2>For Employees</h2>"
        + "<ul>"
        + "<li><b>Understand Company Policies:</b> Familiarize yourself with the code of conduct and grievance procedures.</li>"
        + "<li><b>Respond Promptly to Notices:</b> If issued a Notice to Explain, provide a clear and factual response.</li>"
        + "<li><b>Seek Assistance:</b> Consult HR, a union representative, or legal counsel if you feel the disciplinary action is unjust.</li>"
        + "</ul>"
        + "<p>By ensuring that disciplinary actions are fair, transparent, and lawful, both employers and employees can maintain a productive and harmonious workplace.</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Disciplinary Actions");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(316, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(320, 320, 320))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 787, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DiscipActions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DiscipActions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DiscipActions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DiscipActions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DiscipActions().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
