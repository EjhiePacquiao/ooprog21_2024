/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class EmployerObli extends javax.swing.JFrame {

    /**
     * Creates new form EmployerObli
     */
    public EmployerObli() {
        initComponents();
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        
String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
       + "<h1>Employer Obligations in the Philippines</h1>"
        + "<p>Employers in the Philippines, whether operating as a business entity or as a freelancer, have significant obligations to fulfill in order to ensure compliance with labor laws. Below is a guide to the obligations that must be followed and the benefits available to employers.</p>"
        + "<h2>Employer Obligations</h2>"
        + "<ul>"
        + "<li><b>Payment of Minimum Wage</b><br>Employers must comply with regional wage rates set by the regional wage boards, as minimum wages vary depending on the region and industry. Staying updated on these rates is crucial to avoid penalties.</li>"
        + "<li><b>Timely Payment of Wages</b><br>Employers must ensure that wages are paid regularly, at least once a month, without delay. This includes timely payment of overtime, bonuses, and other compensation.</li>"
        + "<li><b>Accurate Wage Calculations</b><br>Employers must ensure accurate wage calculations, including overtime, holiday pay, and night shift pay. It is essential to be aware of legal work hours, rest periods, and break times to avoid wage discrepancies.</li>"
        + "<li><b>Providing Pay Slips</b><br>Employers are required to provide detailed pay slips that outline wages earned, deductions, and net pay, distributed on the day of salary payment. Electronic pay slips should adhere to data privacy laws.</li>"
        + "<li><b>Contributions to Social Security System (SSS)</b><br>Employers must contribute to the SSS, which provides benefits such as retirement, sickness, maternity, and death benefits. Timely and accurate payments based on employee compensation are required.</li>"
        + "<li><b>Contributions to PhilHealth and Pag-IBIG</b><br>Employers must contribute to PhilHealth for health insurance and Pag-IBIG for housing loans and financial assistance. Contributions should reflect employees' earnings and be made regularly.</li>"
        + "<li><b>Compliance with Occupational Safety and Health Standards</b><br>Employers must ensure the workplace adheres to safety and health standards set by the Department of Labor and Employment (DOLE), including conducting regular inspections, providing safety gear, and offering training.</li>"
        + "<li><b>13th Month Pay</b><br>Employers must provide the 13th-month pay, equivalent to one-twelfth of the employee's basic salary, to all employees, full-time or part-time, on or before December 24th each year.</li>"
        + "<li><b>Labor Standards Compliance</b><br>Employers must comply with labor laws regarding work hours, overtime pay, and ensure no employee works beyond legal limits without compensation.</li>"
        + "<li><b>Leave Benefits</b><br>Employers must grant the following leave benefits in accordance with the law: Sick Leave, Vacation Leave, Maternity Leave, Paternity Leave, Parental Leave (for solo parents), and Leave for Victims of Domestic Violence.</li>"
        + "<li><b>Employee Welfare Programs</b><br>Employers must establish health, wellness, and safety programs for employees, including mental health support and regular health checks.</li>"
        + "<li><b>Dispute Resolution</b><br>Employers should have a grievance mechanism in place to address employee complaints and resolve disputes.</li>"
        + "<li><b>Providing Equal Opportunities and Non-Discrimination</b><br>Employers must ensure equal opportunities in hiring, promotions, pay, and training, free from discrimination based on gender, religion, disability, etc.</li>"
        + "<li><b>Training and Development</b><br>Employers should provide employees with opportunities for career growth, offering training, workshops, and seminars to enhance skills.</li>"
        + "<li><b>Retirement Benefits</b><br>Employers must provide retirement benefits to employees who reach the retirement age, in addition to SSS benefits, as stipulated by law.</li>"
        + "<li><b>Notification of Termination</b><br>Employers must notify employees in writing and follow due process when terminating employment, ensuring compliance with labor laws.</li>"
        + "<li><b>Compliance with Work-Life Balance Regulations</b><br>Employers must ensure a healthy work-life balance for employees by adhering to regulations on work hours and rest days, and offering flexible working arrangements when possible.</li>"
        + "<li><b>Employment Contract</b><br>Employers must provide a formal written employment contract that clearly outlines job duties, compensation, and benefits. This contract must be signed by both parties before employment begins.</li>"
        + "<li><b>Health and Safety Programs</b><br>Employers must implement health and safety programs, including regular safety drills, first-aid training, and health protocols, especially during public health emergencies.</li>"
        + "</ul>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Employer Obligation");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(317, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(280, 280, 280))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jScrollPane1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 5, true));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployerObli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployerObli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployerObli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployerObli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployerObli().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
