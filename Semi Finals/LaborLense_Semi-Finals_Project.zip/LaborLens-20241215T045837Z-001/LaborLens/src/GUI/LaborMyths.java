/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class LaborMyths extends javax.swing.JFrame {

    /**
     * Creates new form LaborMyths
     */
    public LaborMyths() {
        initComponents();
        
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Labor Law Myths in the Philippines: Debunking Common Misconceptions</h1>"
        + "<p>In the workplace, knowledge is power, especially when it comes to understanding labor rights and responsibilities. However, there are numerous myths and misconceptions about Philippine labor laws that can lead to confusion, misunderstandings, and even exploitation. Here, we debunk some of the most common labor law myths and clarify the realities behind them.</p>"
        + "<h2>Myth 1: Probationary Employees Have No Rights</h2>"
        + "<p><b>Reality:</b> One of the most common misconceptions is that probationary employees do not have the same rights as regular employees. In truth, probationary employees are entitled to a range of protections under the Labor Code. They have the right to:</p>"
        + "<ul>"
        + "<li>Receive fair compensation that is not lower than the minimum wage.</li>"
        + "<li>Enjoy basic benefits such as paid leaves (sick leave, vacation leave) and 13th-month pay.</li>"
        + "<li>Be regularized after six months if their performance meets the standards outlined by the employer at the start of employment.</li>"
        + "</ul>"
        + "<p>It's important to note that while probationary employees can be terminated if they fail to meet the criteria for regularization, they still have the right to due process, including a chance to explain their side.</p>"
        + "<h2>Myth 2: Employees Cannot Be Fired Without a Just Cause</h2>"
        + "<p><b>Reality:</b> While it’s true that employees cannot be dismissed without just cause, there are several nuances to this protection. Employers can terminate employees for just or authorized causes under the Labor Code, including:</p>"
        + "<ul>"
        + "<li>Serious misconduct (e.g., theft or harassment).</li>"
        + "<li>Gross and habitual neglect of duties (e.g., chronic absenteeism).</li>"
        + "<li>Authorized causes such as business closure, retrenchment, or redundancy.</li>"
        + "</ul>"
        + "<p>However, it’s crucial to remember that dismissal for these causes must be done in accordance with due process. This includes giving the employee a chance to explain themselves and issuing a written notice before taking any action.</p>"
        + "<h2>Myth 3: Employers Can Pay Workers Under the Table to Avoid Taxes</h2>"
        + "<p><b>Reality:</b> Paying workers under the table is illegal and violates labor and tax laws. Employers must comply with both labor laws and tax regulations by providing full, correct, and timely wages and paying the necessary taxes, including contributions to the Social Security System (SSS), PhilHealth, and Pag-IBIG.</p>"
        + "<p>Workers also have the right to a payslip that details their earnings and deductions, and they should be given a proper 13th-month pay at the end of the year. Failure to comply with these obligations can lead to significant legal penalties for employers.</p>"
        + "<h2>Myth 4: Employees Can’t Refuse Unsafe Work</h2>"
        + "<p><b>Reality:</b> Under the Occupational Safety and Health Standards (OSHS), employees have the right to refuse unsafe work without fear of retaliation. If an employee reasonably believes that performing a particular task would expose them to significant health or safety risks, they can refuse to do it until the situation is resolved.</p>"
        + "<p>Employers are required to provide a safe working environment and to address any safety concerns raised by employees promptly. Failure to do so could lead to legal consequences, including fines or the suspension of operations.</p>"
        + "<h2>Myth 5: Freelancers and Independent Contractors Are Not Protected by Labor Laws</h2>"
        + "<p><b>Reality:</b> While freelancers and independent contractors are not covered by the same laws as regular employees, they are not entirely exempt from protection. Freelancers are governed by the Civil Code and should have clear contracts that specify the terms of their engagement.</p>"
        + "<p>These contracts should cover:</p>"
        + "<ul>"
        + "<li>Compensation: Freelancers must be paid the agreed-upon amount as specified in their contracts.</li>"
        + "<li>Deadlines and Deliverables: Freelancers should have clear expectations about the work they are hired to perform.</li>"
        + "<li>Intellectual Property: Freelancers should clarify ownership of intellectual property rights related to their work.</li>"
        + "</ul>"
        + "<p>If a freelancer is treated as an employee in practice (e.g., working regularly with one employer, receiving benefits), they may be considered an employee under the law and entitled to benefits such as SSS, PhilHealth, and Pag-IBIG contributions.</p>"
        + "<h2>Myth 6: Overtime Pay Is Only Given After 8 Hours of Work</h2>"
        + "<p><b>Reality:</b> According to Philippine labor law, overtime pay applies for work exceeding the standard 40-hour workweek, not just after 8 hours of work in a single day. For employees working beyond 8 hours in a single day, they are entitled to 1.5x their regular hourly rate for the first 8 hours and 2x their hourly rate for any time worked beyond that.</p>"
        + "<p>Employers should also ensure that employees are properly compensated for work done on rest days, holidays, and special non-working holidays. Different pay rates apply depending on the nature of the day worked.</p>"
        + "<h2>Myth 7: Salaries Can Be Deducted for Mistakes Made at Work</h2>"
        + "<p><b>Reality:</b> Employers cannot automatically deduct wages from employees for errors or mistakes made during work. Wage deductions are strictly regulated by the Labor Code and may only be made for specific reasons such as:</p>"
        + "<ul>"
        + "<li>Absences without leave.</li>"
        + "<li>Damage to company property, but only after due process (e.g., investigation and agreement on the amount of damage).</li>"
        + "</ul>"
        + "<p>Employers cannot arbitrarily reduce employees' wages for mistakes, as this would violate the employee’s rights to fair compensation.</p>"
        + "<h2>Myth 8: Overtime is Always Optional for Employees</h2>"
        + "<p><b>Reality:</b> While employees cannot be forced to work overtime against their will, employers are within their rights to require overtime work if the business needs demand it, provided it is compensated accordingly. Overtime work must be properly authorized by the employer and compensated with the appropriate rate.</p>"
        + "<p>However, employees can refuse overtime work if it violates the law or if they are unable to do so due to personal or health reasons. If overtime is deemed mandatory due to operational needs, the employee should still be paid at the applicable overtime rates.</p>"
        + "<h2>Myth 9: An Employee’s Leave Benefits Are Always Paid Out Upon Resignation</h2>"
        + "<p><b>Reality:</b> Employees are entitled to certain leave benefits (e.g., vacation, sick leave, etc.), but they are not automatically paid out upon resignation unless stipulated by the employer’s policy or the employment contract. Unused leave credits may be paid out in some cases, but this is at the employer's discretion unless there is a binding policy or labor agreement that mandates it.</p>"
        + "<p>Additionally, if an employee resigns without giving the proper notice or breaches the terms of the contract, they may forfeit the right to some leave benefits.</p>"
        + "<p>Understanding labor laws is crucial for both employers and employees in the Philippines. By debunking common myths, workers can better protect their rights and ensure they are receiving the benefits and protections they are entitled to under the law. Whether you're an employer seeking to comply with regulations or an employee asserting your rights, knowledge of the law empowers both parties to maintain fair and harmonious working relationships.</p>"
        + "<p>As always, if in doubt, it's best to consult with a labor lawyer or the Department of Labor and Employment (DOLE) for guidance on any issues related to labor law.</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Labor Law Myths");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(357, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(289, 289, 289))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LaborMyths.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LaborMyths.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LaborMyths.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LaborMyths.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LaborMyths().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
