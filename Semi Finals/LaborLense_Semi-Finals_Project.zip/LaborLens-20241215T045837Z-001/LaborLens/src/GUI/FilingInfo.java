/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class FilingInfo extends javax.swing.JFrame {

    /**
     * Creates new form FilingInfo
     */
    public FilingInfo() {
        initComponents();
        
       jTextPane2.setContentType("text/html");
       jTextPane2.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
       // HTML content to be displayed
        String htmlContent = "<html>"
        +  "<head>"
        + "<style>"
        + "h2 { font-size: 16px; color: maroon; }"
        + "</style>"
        + "</head>"
        + "<h1>How to File Your Taxes</h1>"
        + "<p>Filing taxes can seem daunting, but it's a crucial part of being a responsible citizen. This guide provides essential information on how to file taxes, important deadlines, and the documents you'll need.</p>"
        + "<p>There are several options in filing taxes:</p>"
        + "<ul>"
        + "<li><b>Online Filing:</b> This is the most convenient and efficient way to file taxes. You can use the Bureau of Internal Revenue (BIR)'s eBIRForms system to file your taxes electronically.</li>"
        + "<li><b>Manual Filing:</b> You can also file your taxes manually by filling out the required forms and submitting them to a BIR office.</li>"
        + "<li><b>Tax Preparation Services:</b> If you find filing taxes confusing, you can hire a tax preparation service to help you file your taxes accurately and on time.</li>"
        + "</ul>"
        + "<h2>eBIRForms</h2>"
        + "<p>The Electronic Bureau of Internal Revenue Forms (eBIRForms) was created to make tax preparation and filing easier and more convenient for taxpayers. By using eBIRForms, the Bureau of Internal Revenue (BIR) can capture and store tax data more efficiently and accurately, benefiting both taxpayers and the government.</p>"
        + "<p>The eBIRForms system has two main components: the Offline eBIRForms Package and the Online eBIRForms System.</p>"
        + "<h3>1. Offline eBIRForms Package</h3>"
        + "<ul>"
        + "<li>The Offline eBIRForms Package is a software you can download to fill out tax forms without needing an internet connection. Instead of manually writing on printed forms, you can:</li>"
        + "<ul>"
        + "<li>Encode data directly into the software.</li>"
        + "<li>Validate, edit, save, delete, or print your tax forms.</li>"
        + "<li>Benefit from automatic computations and data validation to reduce errors.</li>"
        + "<li>Once the forms are complete, you can submit them online using the Online eBIRForms System.</li>"
        + "</ul>"
        + "</ul>"
        + "<h3>2. Online eBIRForms System</h3>"
        + "<ul>"
        + "<li>The Online eBIRForms System allows you to submit completed tax forms electronically. It offers features such as:</li>"
        + "<ul>"
        + "<li>Secure user accounts for taxpayers, Accredited Tax Agents (ATAs), and Tax Software Providers (TSPs).</li>"
        + "<li>Automatic computation of penalties for late filings.</li>"
        + "<li>The ability for ATAs to file on behalf of their clients.</li>"
        + "<li>A facility for TSPs to test and certify their software for compliance with BIR standards.</li>"
        + "</ul>"
        + "</ul>"
        + "<h2>Filing Taxes Step-by-Step</h2>"
        + "<p>Filing taxes involves preparing, submitting, and paying taxes to the Bureau of Internal Revenue (BIR) in the Philippines. Here's a step-by-step guide for individuals and businesses:</p>"
        + "<h3>1. Determine Your Taxpayer Classification</h3>"
        + "<ul>"
        + "<li><b>Individual:</b> Employee, self-employed, freelancer, or professional.</li>"
        + "<li><b>Business Entity:</b> Corporation, partnership, or sole proprietorship.</li>"
        + "</ul>"
        + "<h3>2. Register with the BIR</h3>"
        + "<ul>"
        + "<li>For new taxpayers: Secure a Taxpayer Identification Number (TIN) by registering through BIR Form 1901 (for individuals) or BIR Form 1903 (for corporations).</li>"
        + "<li>For existing taxpayers: Verify your TIN and ensure your registration is up to date.</li>"
        + "</ul>"
        + "<h3>3. Prepare Your Documents</h3>"
        + "<ul>"
        + "<li>Collect all relevant documents, such as:</li>"
        + "<ul>"
        + "<li>Certificate of Withholding Tax (Form 2316) for employees.</li>"
        + "<li>Income records (e.g., receipts, invoices).</li>"
        + "<li>Financial statements for businesses.</li>"
        + "<li>Tax declaration forms (e.g., Form 1701 for individuals, Form 1702 for businesses).</li>"
        + "</ul>"
        + "</ul>"
        + "<h3>4. Choose the Appropriate Tax Form</h3>"
        + "<ul>"
        + "<li><b>Individuals:</b> Use BIR Form 1700 (for those with only compensation income) or 1701/1701A (for self-employed and professionals).</li>"
        + "<li><b>Corporations and Partnerships:</b> Use BIR Form 1702.</li>"
        + "<li><b>Other Taxes:</b> Use specific forms for VAT (2550M/2550Q), percentage tax (2551Q), withholding taxes (1601-E/F), etc.</li>"
        + "</ul>"
        + "<h3>5. Compute Your Taxes</h3>"
        + "<ul>"
        + "<li>For income tax: Use the tax brackets and rates applicable to your classification.</li>"
        + "<li>Consider allowable deductions, such as:</li>"
        + "<ul>"
        + "<li>Optional Standard Deduction (OSD): Up to 40% of gross sales/revenue.</li>"
        + "<li>Itemized Deductions: Documented business expenses (e.g., rent, utilities).</li>"
        + "</ul>"
        + "</ul>"
        + "<h3>6. File Your Tax Return</h3>"
        + "<ul>"
        + "<li>Online via eBIRForms:</li>"
        + "<ul>"
        + "<li>Download the eBIRForms software.</li>"
        + "<li>Fill out the appropriate form offline.</li>"
        + "<li>Submit the form via the eBIRForms online system.</li>"
        + "</ul>"
        + "<li>Over-the-counter:</li>"
        + "<ul>"
        + "<li>Print the completed tax form.</li>"
        + "<li>Submit the form to the Revenue District Office (RDO) where you are registered or authorized banks.</li>"
        + "</ul>"
        + "</ul>"
        + "<h3>7. Pay Your Taxes</h3>"
        + "<ul>"
        + "<li><b>Online Methods:</b></li>"
        + "<ul>"
        + "<li>GCash, PayMaya, or debit/credit cards via BIR’s eFPS or eBIRForms.</li>"
        + "<li>Authorized payment channels like LandBank or DBP online.</li>"
        + "</ul>"
        + "<li><b>Over-the-counter:</b></li>"
        + "<ul>"
        + "<li>Accredited banks or payment centers.</li>"
        + "<li>BIR revenue collection offices.</li>"
        + "</ul>"
        + "</ul>"
        + "<h3>8. Retain Copies of Your Filing</h3>"
        + "<p>Keep copies of your filed tax returns and payment receipts for at least five years for auditing and compliance purposes.</p>"
        + "<h2>Additional Tips</h2>"
        + "<ul>"
        + "<li><b>Deadlines:</b> Familiarize yourself with the BIR’s tax calendar to avoid penalties.</li>"
        + "<li><b>Penalties:</b> Late filings incur surcharges (25% of tax due), interest (12% annually), and compromise penalties.</li>"
        + "<li><b>Consult Professionals:</b> If tax filing seems complex, seek help from a Certified Public Accountant (CPA) or tax agent.</li>"
        + "</ul>"
            + "</html>";

    // Apply the HTML content to the JTextPane
    jTextPane2.setText(htmlContent);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Filing Information");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(362, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(325, 325, 325))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(21, 21, 21))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 120));

        jScrollPane3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 5, true));

        jTextPane2.setEditable(false);
        jTextPane2.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane3.setViewportView(jTextPane2);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 150, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 787, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FilingInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FilingInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FilingInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FilingInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FilingInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextPane jTextPane2;
    // End of variables declaration//GEN-END:variables
}
