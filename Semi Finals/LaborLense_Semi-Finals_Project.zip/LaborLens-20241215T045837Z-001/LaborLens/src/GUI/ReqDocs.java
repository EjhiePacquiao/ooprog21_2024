/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class ReqDocs extends javax.swing.JFrame {

    /**
     * Creates new form ReqDocs
     */
    public ReqDocs() {
        initComponents();
        jTextPane1.setContentType("text/html"); // Set the JTextPane content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>Required Documents for Tax Filing</h1>"
        + "<ol>"
        + "<li><b>Form W-2: Wage and Tax Statement</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> This form reports your wages, salaries, and tips earned during the tax year and the taxes withheld from your paycheck.</li>"
        + "<li><b>Who Provides It:</b> Your employer is required to send you this form by January 31st each year.</li>"
        + "<li><b>Use:</b> Essential for filing your income tax return and calculating your tax liability.</li>"
        + "</ul></li>"
        + "<li><b>Form 1099: Income from Other Sources</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> Reports income earned outside of traditional employment, such as freelance or self-employment income, interest from bank accounts, dividends from investments, rental income, etc.</li>"
        + "<li><b>Who Provides It:</b> Issued by the payer of the income, such as clients, banks, or investment firms.</li>"
        + "<li><b>Use:</b> Used to report and calculate taxes on non-salary income.</li>"
        + "</ul></li>"
        + "<li><b>Social Security Numbers (SSN)</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> Your Social Security Number (SSN) and the SSNs of your dependents are required for identification and claiming exemptions or credits.</li>"
        + "<li><b>Who Needs It:</b> Individual taxpayers and dependents (e.g., children or spouse).</li>"
        + "<li><b>Use:</b> Required to claim benefits like the Child Tax Credit or the Earned Income Tax Credit (EITC).</li>"
        + "</ul></li>"
        + "<li><b>Prior Year's Tax Return</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> Serves as a reference for this year’s filing and ensures accuracy in areas such as carryover deductions or tax credits.</li>"
        + "<li><b>Use:</b> Helpful when using tax preparation software or filing online, as some systems require prior-year data for verification or pre-filling forms.</li>"
        + "</ul></li>"
        + "<li><b>Bank Account Information</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> Required if you want your tax refund deposited directly into your bank account.</li>"
        + "<li><b>What You Need:</b> Your bank account number and routing number.</li>"
        + "<li><b>Use:</b> Provides a faster and safer way to receive your refund compared to a mailed check.</li>"
        + "</ul></li>"
        + "<li><b>Receipts and Proof of Expenses</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> Essential for claiming deductions and credits. Examples include charitable donations, medical expenses, and work-related expenses.</li>"
        + "</ul></li>"
        + "<li><b>Education-Related Documents</b>"
        + "<ul>"
        + "<li><b>Form 1098-T:</b> Provided by educational institutions to report tuition and fees.</li>"
        + "<li><b>Purpose:</b> Used to claim education-related credits such as the Lifetime Learning Credit (LLC) or American Opportunity Tax Credit (AOTC).</li>"
        + "</ul></li>"
        + "<li><b>Mortgage and Loan Documents</b>"
        + "<ul>"
        + "<li><b>Form 1098:</b> Reports mortgage interest paid to lenders.</li>"
        + "<li><b>Purpose:</b> Allows homeowners to claim deductions on mortgage interest, reducing taxable income.</li>"
        + "</ul></li>"
        + "<li><b>Investment and Retirement Account Statements</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> For reporting gains, losses, or contributions to retirement accounts such as 401(k) or IRA.</li>"
        + "<li><b>Documents Needed:</b> Year-end statements from brokerage accounts, contribution records to tax-advantaged accounts (e.g., Roth IRA).</li>"
        + "</ul></li>"
        + "<li><b>Health Insurance Information</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> Required if you are claiming health-related deductions or proving compliance with health coverage requirements.</li>"
        + "<li><b>Documents Needed:</b> Proof of coverage under the Affordable Care Act (ACA), if applicable.</li>"
        + "</ul></li>"
        + "<li><b>Business and Self-Employment Records</b>"
        + "<ul>"
        + "<li><b>Purpose:</b> For freelancers, contractors, or small business owners to report income and expenses.</li>"
        + "<li><b>Documents Needed:</b> Profit and loss statements, records of business expenses such as supplies, travel, and utilities.</li>"
        + "</ul></li>"
        + "<li><b>Other Relevant Documents</b>"
        + "<ul>"
        + "<li><b>Childcare Expenses:</b> Receipts and provider information to claim the Child and Dependent Care Credit.</li>"
        + "<li><b>Alimony Payments:</b> Records if applicable to claim deductions or report income.</li>"
        + "<li><b>State and Local Tax Payments (SALT):</b> Records of taxes paid for deductions, if itemizing.</li>"
        + "</ul></li>"
        + "</ol>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Required Documents");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(312, 312, 312))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 130));

        jScrollPane1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 5, true));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 1030, 640));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReqDocs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReqDocs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReqDocs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReqDocs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReqDocs().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
