/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class TaxBracks extends javax.swing.JFrame {

    /**
     * Creates new form TaxBracks
     */
    public TaxBracks() {
        initComponents();
    
        jTextPane2.setContentType("text/html"); // Set content type to HTML
        jTextPane2.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        + "<head>"
        + "<style>"
        + "h2 { color: maroon; }"
        + "table { width: 100%; border-collapse: collapse; margin-top: 10px; }"
        + "th, td { border: 1px solid black; padding: 8px; text-align: left; }"
        + "th { background-color: #f2f2f2; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>TAX BRACKET</h1>"
        + "<p>The TRAIN Law (Republic Act No. 10963), signed on December 19, 2017, and implemented on January 1, 2018, is the first package of the Philippine government’s Comprehensive Tax Reform Program (CTRP). It aims to create a more efficient, equitable, and pro-poor tax system while generating revenue for infrastructure, healthcare, and education. The law revised tax brackets and rates for individual taxpayers, including compensation earners, self-employed individuals, and professionals, simplifying tax computations and reducing the burden on lower-income earners.</p><br>"
        + "<h2>Income Tax Rates for Individuals</h2>"
        + "<p><b>Starting 2024 (Current Rates):</b></p>"
        + "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;'>"
        + "<tr><th>Annual Taxable Income</th><th>Tax Rate</th></tr>"
        + "<tr><td>₱250,000 and below</td><td>0% (Exempt)</td></tr>"
        + "<tr><td>Over ₱250,000 to ₱400,000</td><td>15% of the excess over ₱250,000</td></tr>"
        + "<tr><td>Over ₱400,000 to ₱800,000</td><td>₱22,500 + 20% of the excess over ₱400,000</td></tr>"
        + "<tr><td>Over ₱800,000 to ₱2,000,000</td><td>₱102,500 + 25% of the excess over ₱800,000</td></tr>"
        + "<tr><td>Over ₱2,000,000 to ₱8,000,000</td><td>₱402,500 + 30% of the excess over ₱2,000,000</td></tr>"
        + "<tr><td>Over ₱8,000,000</td><td>₱2,202,500 + 35% of the excess over ₱8,000,000</td></tr>"
        + "</table><br>"
        + "<h2>REVISED WITHHOLDING TAX TABLE</h2>"
        + "<p><b>Effective January 1, 2023 and onwards</b></p>"
        + "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;'>"
        + "<tr><th>MONTHLY</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th></tr>"
        + "<tr><td>Compensation Range</td><td>₱20,833 and below</td><td>₱20,833 - ₱33,332</td><td>₱33,333 - ₱66,666</td><td>₱66,667 - ₱166,666</td><td>₱166,667 - ₱666,666</td><td>₱666,667 and above</td></tr>"
        + "<tr><td>Prescribed Withholding Tax</td><td>0.00</td><td>0.00 +15% over ₱20,833</td><td>₱1,875.00 +20% over ₱33,333</td><td>₱8,541.80 +25% over ₱66,667</td><td>₱33,541.80 +30% over ₱166,667</td><td>₱183,541.80 +35% over ₱666,667</td></tr>"
        + "</table><br>"
        + "<h2>How to Compute Income Tax</h2>"
        + "<p><b>To compute your income tax:</b><br>"
        + "1. <b>Determine Your Taxable Income:</b> Taxable income is your gross income (salary, commissions, etc.) minus allowable deductions (e.g., personal exemptions, contributions).<br>"
        + "2. <b>Identify Your Tax Bracket:</b> Find your annual taxable income in the appropriate tax bracket.<br>"
        + "3. <b>Apply the Tax Rate Formula:</b> Compute the tax based on the bracket formula (e.g., fixed amount + percentage of excess income over the lower limit).</p>"
        + "<h3>Examples of Tax Computation</h3>"
        + "<p><b>Example 1: Monthly Income of ₱42,325 (2024 Rate)</b><br>"
        + "• Taxable Income: ₱42,325<br>"
        + "• Bracket: Category 3 (₱33,333 − ₱66,666)<br>"
        + "• Tax Computation: (₱42,325 − ₱33,333) = 8,992 + 1,875 * 20%)<br>"
        + "• Total Tax Withheld = ₱3,673.40</p>"
        + "<p><b>Example 2: Annual Income ₱1,000,000</b><br>"
        + "Tax Bracket: ₱800,000 lower limit<br>"
        + "o Basic Tax Amount: ₱102,500<br>"
        + "o Excess Tax:<br>"
        + " Excess over ₱800,000: ₱200,000<br>"
        + " Multiply by 25%: ₱200,000 × 25% = ₱50,000<br>"
        + "o Total Tax Due: ₱102,500 + ₱50,000 = ₱152,500</p><br>"
        + "<h2>Key Updates and Guidelines:</h2>"
        + "<ul>"
        + "<li><b>Non-Taxable Benefits:</b> 13th-month pay and other benefits exemption threshold increased from ₱82,000 to ₱90,000.</li>"
        + "<li><b>Taxable Income Formula:</b> Gross compensation income minus non-taxable income/benefits:<br>"
        + "<ul>"
        + "<li>13th-month pay and other benefits</li>"
        + "<li>De minimis benefits</li>"
        + "<li>Employee's contributions to SSS, GSIS, PHIC, Pag-IBIG, and union dues</li>"
        + "</ul></li>"
        + "<li><b>Husband and Wife Taxation:</b> Income tax must be computed separately based on their respective taxable incomes. Any income not attributable to either spouse will be divided equally.</li>"
        + "<li><b>Minimum Wage Earners:</b> Exempt from income tax on statutory minimum wage rates. Exemptions also apply to:<br>"
        + "<ul>"
        + "<li>Holiday pay</li>"
        + "<li>Overtime pay</li>"
        + "<li>Night shift differential pay</li>"
        + "<li>Hazard pay</li>"
        + "</ul></li>"
        + "</ul><br>"
        + "<h2>Key Notes</h2>"
        + "<ul>"
        + "<li><b>Exemptions and Deductions:</b> Individuals earning below ₱250,000 annually are exempt from income tax. For freelancers or self-employed individuals, optional standard deductions (OSD) or itemized deductions may be applied.</li>"
        + "<li><b>Deadlines:</b> Income tax returns (ITR) must be filed on or before April 15th of the following year.</li>"
        + "<li><b>Penalties for Late Filing:</b> A surcharge of 25%, 12% interest per annum, and additional compromise penalties may apply.</li>"
        + "</ul>"
        + "</body>"
        + "</html>";

        jTextPane2.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(0, 51, 51));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Tax Brackets");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(352, 352, 352)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(336, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jScrollPane2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 5, true));

        jTextPane2.setEditable(false);
        jTextPane2.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane2.setViewportView(jTextPane2);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 930, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TaxBracks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TaxBracks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TaxBracks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TaxBracks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TaxBracks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextPane jTextPane2;
    // End of variables declaration//GEN-END:variables
}
