/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

/**
 *
 * @author Jazzy
 */
public class GenTips extends javax.swing.JFrame {

    /**
     * Creates new form GenTips
     */
    public GenTips() {
        initComponents();
        
        jTextPane1.setContentType("text/html"); // Set content type to HTML
        jTextPane1.setFont(new java.awt.Font("Times New Roman", java.awt.Font.PLAIN, 16));
        
        String htmlContent = "<html>"
        +  "<head>"
        + "<style>"
        + "h2 { font-size: 16px; color: maroon; }"
        + "</style>"
        + "</head>"
        + "<body>"
        + "<h1>General Tips for Filipino Employees: Thriving in Your Career and Financial Life</h1>"
        + "<p>Being a Filipino employee comes with its own set of challenges and opportunities. Whether you’re just starting your career or are already an experienced professional, adopting smart strategies can help you excel at work, manage your finances effectively, and grow as an individual. Here are general tips to help you thrive:</p>"
        + "<ol>"
        + "<li><b>Understand Your Employment Rights</b><br>"
        + "Knowing your rights under Philippine labor laws empowers you to navigate your employment confidently. Key areas to focus on:<ul>"
        + "<li><b>Fair Pay:</b> Ensure your salary complies with the minimum wage and includes applicable benefits like 13th-month pay, overtime pay, and holiday pay.</li>"
        + "<li><b>Leave Entitlements:</b> Familiarize yourself with mandatory leave benefits, such as service incentive leave and special leave for women.</li>"
        + "<li><b>Safe Workplace:</b> Employers must provide a healthy and secure working environment under the Occupational Safety and Health Standards (OSHS).</li></ul></li>"
        + "<li><b>Manage Your Time Wisely</b><br>"
        + "Time management is crucial for achieving a healthy work-life balance and boosting productivity.<ul>"
        + "<li><b>Set Priorities:</b> Use tools like the Eisenhower Matrix to focus on urgent and important tasks.</li>"
        + "<li><b>Avoid Multitasking:</b> It can lower productivity. Instead, focus on one task at a time for better results.</li>"
        + "<li><b>Leverage Technology:</b> Apps like Google Calendar or Notion can help organize your tasks and set reminders.</li></ul></li>"
        + "<li><b>Budget and Save Regularly</b><br>"
        + "Financial stability starts with disciplined budgeting and saving.<ul>"
        + "<li><b>Follow the 50/30/20 Rule:</b> Allocate 50% of your income to needs, 30% to wants, and 20% to savings or investments.</li>"
        + "<li><b>Create an Emergency Fund:</b> Aim to save at least 3-6 months’ worth of expenses.</li>"
        + "<li><b>Avoid unnecessary debts:</b> Live within your means and pay off credit cards in full each month.</li></ul></li>"
        + "<li><b>Take Advantage of Your Benefits</b><br>"
        + "Government-mandated benefits provide financial security and support for employees.<ul>"
        + "<li>Maximize your contributions to SSS, PhilHealth, and Pag-IBIG for retirement, healthcare, and housing benefits.</li>"
        + "<li>Consider the Pag-IBIG MP2 Program for tax-free savings with higher returns than regular savings accounts.</li>"
        + "<li>Ensure your employer remits your contributions on time; you can verify this through online portals.</li></ul></li>"
        + "<li><b>Invest in Your Career Growth</b><br>"
        + "Continuous learning and skill development are key to staying relevant and competitive in your field.<ul>"
        + "<li>Enroll in free or affordable online courses to upgrade your skills. Platforms like Coursera and TESDA offer excellent options.</li>"
        + "<li>Attend industry events, seminars, and webinars to stay updated on trends.</li>"
        + "<li>Seek feedback from colleagues and supervisors to identify areas for improvement.</li></ul></li>"
        + "<li><b>Build Strong Workplace Relationships</b><br>"
        + "Good relationships with colleagues and supervisors can make your work environment more enjoyable and productive.<ul>"
        + "<li>Practice active listening during conversations.</li>"
        + "<li>Resolve conflicts professionally by focusing on solutions, not blame.</li>"
        + "<li>Offer help to teammates when needed and foster a spirit of collaboration.</li></ul></li>"
        + "<li><b>Prioritize Work-Life Balance</b><br>"
        + "Burnout is a common issue, especially in fast-paced industries.<ul>"
        + "<li>Set boundaries between work and personal life. Avoid checking emails or taking calls outside of work hours unless necessary.</li>"
        + "<li>Use your vacation and leave entitlements to rest and recharge.</li>"
        + "<li>Pursue hobbies and spend quality time with loved ones to maintain a fulfilling life outside work.</li></ul></li>"
        + "<li><b>Stay Informed About Labor Laws</b><br>"
        + "Labor laws in the Philippines evolve, and staying updated ensures you understand your rights and obligations.<ul>"
        + "<li>Regularly check updates from the Department of Labor and Employment (DOLE).</li>"
        + "<li>Join employee forums or groups that discuss workplace issues and solutions.</li></ul></li>"
        + "<li><b>Plan for the Future</b><br>"
        + "Thinking ahead helps you build a secure financial and professional future.<ul>"
        + "<li>Start saving for retirement as early as possible.</li>"
        + "<li>Explore investment options such as mutual funds, government bonds, or real estate to grow your wealth.</li>"
        + "<li>Set career goals and regularly evaluate your progress to stay on track.</li></ul></li>"
        + "<li><b>Communicate Effectively</b><br>"
        + "Clear and confident communication is essential in any workplace.<ul>"
        + "<li>Be proactive in sharing your ideas and asking for feedback.</li>"
        + "<li>Practice concise and professional email etiquette.</li>"
        + "<li>Learn to handle constructive criticism positively and use it for self-improvement.</li></ul></li>"
        + "</ol>"
        + "<p>Success as an employee isn’t just about working hard—it’s about working smart. By following these general tips, you can enhance your productivity, protect your rights, manage your finances, and create a more fulfilling career path.</p>"
        + "<p>Start implementing these strategies today and pave the way for a brighter and more secure future!</p>"
        + "</body>"
        + "</html>";

        jTextPane1.setText(htmlContent); // Set the text content

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 10));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("General Tips");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(363, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(346, 346, 346))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 120));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255, 150));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 150, 920, 570));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backdjljddhbfbfbfb.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 1030, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1064, 795));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GenTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GenTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GenTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GenTips.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GenTips().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
